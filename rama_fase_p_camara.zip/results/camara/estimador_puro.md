# Estimador en Python puro vs numpy

Generado por `camara/pruebas/comparar_puro.py` con 60 imagenes sinteticas (QVGA RGB, error de pose 0).

| | numpy (`lane_estimator.py`) | Python puro (`lane_estimator_puro.py`) |
|---|---|---|
| Error lateral medio | 0.1 cm | 0.1 cm |
| Tiempo por imagen en este PC (x86_64) | 1.8 ms | 13.4 ms |
| Meta roja detectada (+-8 cm) | — | 12 / 12 |

Diferencia media entre ambos estimadores: 0.1 cm.

En el NAO V6 (Intel Atom E3845) se espera un tiempo de 3 a 8 veces mayor que en un PC de escritorio **(a validar en la sesion 1, paso 65)**. Con la camara a 10 FPS hay 100 ms por imagen.

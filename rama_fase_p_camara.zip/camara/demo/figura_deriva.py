# -*- coding: utf-8 -*-
"""Figura: cuanto se sale del centro un robot que camina "perfectamente recto" segun su IMU.

(a) Error de rumbo inicial al colocarlo en la salida: la IMU lo toma como "recto" (rumbo objetivo = rumbo de
    salida, seccion 5.3 de docs/plan_rl_carrera.md), asi que nunca lo corrige.
(b) Sesgo de rumbo que la IMU no ve (deriva de AngleZ, deslizamiento): desvio acumulado a 0.2 y 0.3 m/s.

Uso (desde la raiz del repo):  uv run python camara/demo/figura_deriva.py  ->  docs/img/fase_p_deriva_sin_camara.png
"""
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

OUT = Path(__file__).resolve().parents[2] / "docs" / "img" / "fase_p_deriva_sin_camara.png"
MARGEN = 0.30   # m, margen lateral descontando el ancho de los pies (seccion 1 de docs/plan_rl_carrera.md)

fig, ax = plt.subplots(1, 2, figsize=(12, 4.4))
s = np.linspace(0, 5, 200)
for deg, col in ((1, "#9aa0a6"), (2, "#fbbc04"), (3, "#e8710a"), (5, "#c5221f")):
    ax[0].plot(s, 100 * s * math.tan(math.radians(deg)), color=col, lw=2.2, label="%d grados al colocarlo" % deg)
ax[0].axhline(100 * MARGEN, color="k", ls="--", lw=1.2)
ax[0].text(0.1, 100 * MARGEN + 1.5, "se sale del carril (~30 cm)", fontsize=9)
ax[0].set_xlabel("avance en el carril [m]")
ax[0].set_ylabel("desvio lateral [cm]")
ax[0].set_title("(a) Error de colocacion en la salida\n(la IMU lo toma como 'recto' y nunca lo corrige)", fontsize=11)
ax[0].set_xlim(0, 5)
ax[0].set_ylim(0, 50)
ax[0].grid(alpha=0.3)
ax[0].legend(fontsize=9, loc="upper left")

t = np.linspace(0, 30, 300)
for rate, v, col, ls in ((0.5, 0.2, "#fbbc04", "-"), (1.0, 0.2, "#e8710a", "-"), (2.0, 0.2, "#c5221f", "-"),
                         (1.0, 0.3, "#e8710a", "--")):
    w = math.radians(rate)
    x = v * np.sin(w * t) / w
    y = v * (1 - np.cos(w * t)) / w
    keep = x <= 5.0
    ax[1].plot(x[keep], 100 * y[keep], color=col, ls=ls, lw=2.2, label="%.1f grados/s a %.1f m/s" % (rate, v))
ax[1].axhline(100 * MARGEN, color="k", ls="--", lw=1.2)
ax[1].set_xlabel("avance en el carril [m]")
ax[1].set_ylabel("desvio lateral [cm]")
ax[1].set_title("(b) Giro lento que la IMU no ve\n(deriva de AngleZ, deslizamiento en la duela)", fontsize=11)
ax[1].set_xlim(0, 5)
ax[1].set_ylim(0, 50)
ax[1].grid(alpha=0.3)
ax[1].legend(fontsize=9, loc="upper left")
fig.tight_layout()
fig.savefig(OUT, dpi=100)
print("Figura:", OUT)
print("Desvio a 5 m por error de colocacion: " + ", ".join("%d deg -> %.0f cm" % (g, 500 * math.tan(math.radians(g))) for g in (1, 2, 3, 5)))

# -*- coding: utf-8 -*-
"""Figura de los 4 pasos de la vision sobre una imagen de la camara simulada del NAO.

Uso (desde la raiz del repo):  uv run python camara/demo/figura_pasos.py  ->  docs/img/fase_p_vision_pasos.png
"""
import sys, math
from pathlib import Path
import numpy as np
R = Path(__file__).resolve().parents[2]; OUT = str(R / "docs" / "img" / "fase_p_vision_pasos.png"); sys.path.insert(0, str(R / "camara"))
import mujoco
from carril import CameraModel, LaneEstimator
m = mujoco.MjModel.from_xml_path(str(R/"assets/nao/scene_carril.xml")); d = mujoco.MjData(m)
mujoco.mj_resetDataKeyframe(m, d, m.key("home").id)
D, PSI = 0.10, math.radians(8)            # robot 10 cm a la izquierda, girado 8 grados a la izquierda
d.qpos[0], d.qpos[1] = 1.5, D
d.qpos[3:7] = [math.cos(PSI/2), 0, 0, math.sin(PSI/2)]
mujoco.mj_forward(m, d)
cid = m.camera("CameraBottom").id
r = mujoco.Renderer(m, 240, 320); r.update_scene(d, camera=cid); img = r.render()
# pose camara -> robot (convencion NAOqi)
p = d.cam_xpos[cid]; Rm = d.cam_xmat[cid].reshape(3,3)
Rn = np.column_stack((-Rm[:,2], -Rm[:,0], Rm[:,1]))
pl, pr = d.site("left_foot").xpos, d.site("right_foot").xpos
o = np.array([(pl[0]+pr[0])/2, (pl[1]+pr[1])/2, 0]); c, s = math.cos(-PSI), math.sin(-PSI)
Rz = np.array([[c,-s,0],[s,c,0],[0,0,1]]); T = np.eye(4); T[:3,:3] = Rz@Rn; T[:3,3] = Rz@(p-o)
cam = CameraModel(320, 240, 54.7, 42.5); est = LaneEstimator(cam)
bgr = np.ascontiguousarray(img[:, :, ::-1]); e = est.process(bgr, T)
print("real d=%.3f psi=%.1f | est d=%.3f psi=%.1f lineas=%d" % (D, 8, e.d, math.degrees(e.psi), e.n_lines))
# reconstruir pasos intermedios para dibujarlos
rows = est.rows; sub = bgr[rows].astype(np.float32)
gray = 0.114*sub[:,:,0] + 0.587*sub[:,:,1] + 0.299*sub[:,:,2]
k = est.local_window; pad = np.pad(gray, ((0,0),(k//2+1,k//2)), mode="edge"); cs = np.cumsum(pad, axis=1)
bg = (cs[:,k:] - cs[:,:-k]) / float(k)
dark = (gray < bg*est.dark_ratio) & ((bg-gray) > np.maximum(est.min_contrast, est.rel_contrast*bg))
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 4, figsize=(18, 5.2), gridspec_kw=dict(width_ratios=[1, 1, 1, 1.25]))
ax[0].imshow(img); ax[0].set_title("1. Lo que ve la camara\n(320x240 px)", fontsize=12)
ax[1].imshow(img, alpha=0.35)
rr, uu = np.nonzero(dark); ax[1].scatter(uu, rows[rr], s=1.5, c="red")
ax[1].set_title("2. Pixeles mas oscuros que sus vecinos\n(1 de cada 3 filas)", fontsize=12)
ax[2].imshow(img, alpha=0.35); uv = est._uv
ax[2].scatter(uv[:,0], uv[:,1], s=6, c="#00b8d4")
ax[2].set_title("3. Solo tramos con el ancho de la cinta\n(centro de cada tramo)", fontsize=12)
for a in ax[:3]: a.set_xlim(0,320); a.set_ylim(240,0); a.axis("off")
P = est.last_points; a = ax[3]
a.axhspan(-0.5, 2.2, color="#f5e6d3")
a.scatter(P[:,1], P[:,0], s=8, c="#00b8d4", label="puntos en el piso")
xs = np.linspace(0.0, 2.0, 20)
a.plot(e.c_left + e.slope*xs, xs, "k-", lw=2, label="rectas encontradas")
a.plot(e.c_right + e.slope*xs, xs, "k-", lw=2)
a.plot(0.5*(e.c_left+e.c_right) + e.slope*xs, xs, "g--", lw=1.5, label="centro del carril")
a.annotate("", xy=(0, 0.45), xytext=(0, 0), arrowprops=dict(arrowstyle="-|>", color="b", lw=2))
a.plot([0],[0],"bo", ms=9, label="robot (mira hacia arriba)")
yc = 0.5*(e.c_left+e.c_right)
a.annotate("", xy=(yc, 0.0), xytext=(0, 0.0), arrowprops=dict(arrowstyle="<->", color="purple", lw=1.8))
a.text(yc/2, -0.13, "d = %.0f cm" % (100*e.d), color="purple", ha="center", fontsize=11, fontweight="bold")
a.text(yc + e.slope*1.6 - 0.03, 1.6, "psi = %.0f°\n(rumbo)" % math.degrees(e.psi), color="g", fontsize=11, fontweight="bold", ha="left")
a.set_xlim(0.65, -0.65); a.set_ylim(-0.25, 2.1); a.set_aspect("equal")
a.set_xlabel("izquierda <-- lateral [m] --> derecha"); a.set_ylabel("adelante [m]")
a.set_title("4. Proyectados al piso (vista de pajaro)\n+ rectas del carril", fontsize=12)
a.legend(loc="lower left", fontsize=8, bbox_to_anchor=(0, -0.42), ncol=2)
fig.tight_layout(); fig.savefig(OUT, dpi=95)

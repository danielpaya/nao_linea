# -*- coding: utf-8 -*-
"""Reproduce en el PC las imagenes guardadas por race_nao.py (--save-frames) para ajustar parametros.

Uso:
    uv run python camara/robot/replay.py logs/frames_XXXX.npz --out revision/ [--dark-ratio 0.6] [--min-contrast 20]

Imprime la estimacion de cada imagen y guarda figuras (imagen + puntos detectados + rectas) para revisar
a ojo si las lineas se detectan bien sobre la duela real.
"""
from __future__ import division, print_function

import argparse
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from carril import CameraModel, LaneEstimator  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("npz")
    ap.add_argument("--out", default=None, help="carpeta para las figuras")
    ap.add_argument("--every", type=int, default=10, help="guardar figura de 1 de cada N imagenes")
    ap.add_argument("--dark-ratio", type=float, default=0.62)
    ap.add_argument("--min-contrast", type=float, default=10.0)
    ap.add_argument("--hfov", type=float, default=None)
    ap.add_argument("--vfov", type=float, default=None)
    a = ap.parse_args()

    data = np.load(a.npz)
    frames, poses = data["frames"], data["poses"]
    hfov = a.hfov if a.hfov else (float(data["hfov"]) if "hfov" in data.files else 56.3)
    vfov = a.vfov if a.vfov else (float(data["vfov"]) if "vfov" in data.files else 43.7)
    h, w = frames.shape[1:3]
    cam = CameraModel(w, h, hfov, vfov)
    est = LaneEstimator(cam, dark_ratio=a.dark_ratio, min_contrast=a.min_contrast)
    plt = None
    if a.out:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt  # noqa: F811
        if not os.path.isdir(a.out):
            os.makedirs(a.out)
    n_valid, n_two = 0, 0
    for i in range(len(frames)):
        e = est.process(frames[i], poses[i])
        n_valid += e.valid
        n_two += e.n_lines == 2
        print("%4d valido=%d lineas=%d puntos=%3d d=%+.3f psi=%+5.1f rojo=%s"
              % (i, e.valid, e.n_lines, e.n_points, e.d, math.degrees(e.psi),
                 "-" if e.red_dist is None else "%.2f" % e.red_dist))
        if plt is not None and i % a.every == 0:
            fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
            ax[0].imshow(frames[i][:, :, ::-1])
            ax[0].axis("off")
            ax[0].set_title("imagen %d" % i)
            p = est.last_points
            if p.size:
                ax[1].scatter(p[:, 1], p[:, 0], s=4, c="k")
            xs = np.linspace(0.1, 2.0, 20)
            for c in (e.c_left, e.c_right):
                if c is not None:
                    ax[1].plot(c + e.slope * xs, xs, "r-")
            ax[1].plot([0], [0], "b^", ms=10)
            ax[1].invert_xaxis()
            ax[1].set_aspect("equal")
            ax[1].set_title("d=%+.2f m psi=%+.0f deg lineas=%d" % (e.d, math.degrees(e.psi), e.n_lines))
            fig.tight_layout()
            fig.savefig(os.path.join(a.out, "frame_%04d.png" % i), dpi=90)
            plt.close(fig)
    n = len(frames)
    print("\nImagenes: %d | validas: %d (%.0f%%) | con dos lineas: %d" % (n, n_valid, 100.0 * n_valid / max(n, 1), n_two))


if __name__ == "__main__":
    main()

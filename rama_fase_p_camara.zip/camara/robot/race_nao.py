#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""PROTOTIPO de prueba de la vision de carril DENTRO del NAO (Fase P, pasos 70 y 72).

No es el ejecutor final: la integracion definitiva va en PenaltyStack (pasos 64 y 72), donde la salida
de la vision (d, psi, valido) alimenta las 3 observaciones del contrato v2 de la politica. Este script
sirve para validar la vision en la pista real ANTES de tener la politica v2:

  - Camara inferior (QVGA, RGB, 10 FPS, como PenaltyStack) -> posicion en el carril (d, psi)
    -> filtro con odometria -> ALMotion.moveToward con correccion de giro y paso lateral.
  - --dry-run: no camina; solo mide d/psi para comparar con cinta metrica (criterio del paso 70).
  - Arranque: tactil frontal de la cabeza sostenido 0.25 s (como PenaltyStack; reglamento 3.2.5).
  - Paro: boton del pecho sostenido 0.3 s (como PenaltyStack; reglamento 3.2.3). Paro por inclinacion.
  - Ojo: no correr junto al proceso bhuman (ALMotion y LoLA no deben competir por los motores).
  - Meta: al ver la franja roja junto a los pies sigue unos centimetros y se detiene dentro del area.
  - Caida: se levanta solo (ALRobotPosture) y continua; el tiempo no se detiene.

Ejecucion en el robot (Python 2.7 del NAOqi 2.8):
    python race_nao.py                  # carrera
    python race_nao.py --dry-run        # solo estima y muestra d/psi (no camina): para probar moviendo el robot a mano
    python race_nao.py --save-frames 3  # ademas guarda 1 de cada 3 imagenes para analizarlas en el PC
"""
from __future__ import division, print_function

import argparse
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))   # carpeta camara/ (contiene el paquete carril)
sys.path.insert(0, HERE)                    # en el robot se puede copiar carril/ junto a este archivo
from carril import (CameraModel, LaneEstimator, LaneFilter, LaneController,  # noqa: E402
                    transform_from_list, FRAME_ROBOT)

try:
    from naoqi import ALProxy
except ImportError:
    ALProxy = None

CAMERA_BOTTOM = 1
RES_QVGA = 1         # 320 x 240
CS_RGB = 11          # kRGBColorSpace (igual que PenaltyStack: camara inferior, QVGA, RGB)

# Arranque y paro con las mismas teclas y tiempos que PenaltyStack (docs/integracion_penaltystack.md, seccion 3)
KEY_START = "Device/SubDeviceList/Head/Touch/Front/Sensor/Value"     # tactil frontal sostenido 0.25 s
KEY_ABORT = "Device/SubDeviceList/ChestBoard/Button/Sensor/Value"    # boton del pecho sostenido 0.3 s
START_HOLD_S, ABORT_HOLD_S = 0.25, 0.3
KEY_ANGLE_X = "Device/SubDeviceList/InertialSensor/AngleX/Sensor/Value"
KEY_ANGLE_Y = "Device/SubDeviceList/InertialSensor/AngleY/Sensor/Value"


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


class NaoIO(object):
    """Todo el acceso a NAOqi en un solo lugar."""

    def __init__(self, ip, port, fps, head_pitch):
        if ALProxy is None:
            raise RuntimeError("No se encontro el modulo naoqi. Ejecuta este script en el robot (o con el SDK de Python).")
        self.motion = ALProxy("ALMotion", ip, port)
        self.posture = ALProxy("ALRobotPosture", ip, port)
        self.video = ALProxy("ALVideoDevice", ip, port)
        self.memory = ALProxy("ALMemory", ip, port)
        self.head_pitch = head_pitch
        try:
            ALProxy("ALAutonomousLife", ip, port).setState("disabled")  # que nada mueva la cabeza
        except Exception as exc:  # noqa: BLE001
            print("Aviso: no se pudo desactivar ALAutonomousLife:", exc)
        # Liberar suscripciones viejas con el mismo nombre (si el script se corto antes)
        try:
            for sub in self.video.getSubscribers():
                if sub.startswith("carril"):
                    self.video.unsubscribe(sub)
        except Exception:  # noqa: BLE001
            pass
        self.handle = self.video.subscribeCamera("carril", CAMERA_BOTTOM, RES_QVGA, CS_RGB, fps)
        self._odom_prev = None

    def stand(self):
        self.motion.wakeUp()
        self.posture.goToPosture("StandInit", 0.6)
        self.look_down()
        self.motion.moveInit()

    def look_down(self):
        self.motion.setStiffnesses("Head", 1.0)
        self.motion.setAngles(["HeadYaw", "HeadPitch"], [0.0, self.head_pitch], 0.2)

    def image(self):
        """(img BGR HxWx3, T camara->robot) o (None, None)."""
        res = self.video.getImageRemote(self.handle)
        if res is None:
            return None, None
        T = transform_from_list(self.motion.getTransform("CameraBottom", FRAME_ROBOT, True))
        w, h, data = res[0], res[1], res[6]
        img = np.frombuffer(data, dtype=np.uint8).reshape(h, w, 3)
        return img, T

    def odom_delta(self):
        """Desplazamiento (dx, dy, dth) en el marco del robot desde la llamada anterior."""
        x, y, th = self.motion.getRobotPosition(True)
        if self._odom_prev is None:
            self._odom_prev = (x, y, th)
            return 0.0, 0.0, 0.0
        x0, y0, th0 = self._odom_prev
        self._odom_prev = (x, y, th)
        dxw, dyw = x - x0, y - y0
        c, s = math.cos(th0), math.sin(th0)
        return c * dxw + s * dyw, -s * dxw + c * dyw, wrap(th - th0)

    def pressed(self, key):
        try:
            return float(self.memory.getData(key)) > 0.5
        except Exception:  # noqa: BLE001
            return False

    def tilt(self):
        ax = float(self.memory.getData(KEY_ANGLE_X))
        ay = float(self.memory.getData(KEY_ANGLE_Y))
        return max(abs(ax), abs(ay))

    def move(self, vx, vy, vth, cfg):
        self.motion.moveToward(vx, vy, vth, cfg)

    def stop(self):
        self.motion.stopMove()

    def get_up(self):
        self.motion.stopMove()
        time.sleep(0.8)
        self.posture.goToPosture("Stand", 0.8)   # ALRobotPosture se levanta desde el suelo
        self.posture.goToPosture("StandInit", 0.6)
        self.look_down()
        self.motion.moveInit()
        self._odom_prev = None

    def close(self):
        try:
            self.video.unsubscribe(self.handle)
        except Exception:  # noqa: BLE001
            pass


class HoldDetector(object):
    """Un boton cuenta como presionado solo si se mantiene durante hold_s segundos (como PenaltyStack)."""

    def __init__(self, io):
        self.io = io
        self.since = {}

    def held(self, key, hold_s, now):
        if self.io.pressed(key):
            t0 = self.since.setdefault(key, now)
            return now - t0 >= hold_s
        self.since.pop(key, None)
        return False


class Logger(object):
    COLS = ("t", "estado", "valido", "lineas", "d_vis", "psi_vis", "red_dist", "d", "psi", "s", "sigma_d",
            "vx", "vy", "vth", "margen", "ms_vision")

    def __init__(self, folder):
        if not os.path.isdir(folder):
            os.makedirs(folder)
        name = time.strftime("carrera_%Y%m%d_%H%M%S.csv")
        self.path = os.path.join(folder, name)
        self.f = open(self.path, "w")
        self.f.write(",".join(self.COLS) + "\n")

    def row(self, **kw):
        vals = []
        for c in self.COLS:
            v = kw.get(c, "")
            vals.append("%.4f" % v if isinstance(v, float) else str(v))
        self.f.write(",".join(vals) + "\n")

    def close(self):
        self.f.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ip", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9559)
    ap.add_argument("--fps", type=int, default=10, help="10 FPS, como PenaltyStack")
    ap.add_argument("--head-pitch", type=float, default=0.0, help="rad; + mira mas abajo")
    ap.add_argument("--hfov", type=float, default=56.3, help="campo de vision horizontal [grados]")
    ap.add_argument("--vfov", type=float, default=43.7)
    ap.add_argument("--dark-ratio", type=float, default=0.62)
    ap.add_argument("--min-contrast", type=float, default=10.0)
    ap.add_argument("--vx", type=float, default=1.0, help="fraccion de velocidad maxima hacia adelante")
    ap.add_argument("--max-step-x", type=float, default=0.06, help="MaxStepX de la caminata nativa [m]")
    ap.add_argument("--step-freq", type=float, default=1.0, help="MaxStepFrequency normalizada [0, 1]")
    ap.add_argument("--finish-trigger", type=float, default=0.35, help="distancia de la franja roja que activa la meta [m]")
    ap.add_argument("--post-finish", type=float, default=0.45, help="avance tras activar la meta antes de parar [m]")
    ap.add_argument("--max-distance", type=float, default=6.5, help="tope de seguridad por odometria [m]")
    ap.add_argument("--time-limit", type=float, default=175.0)
    ap.add_argument("--lost-timeout", type=float, default=1.5)
    ap.add_argument("--fall-tilt", type=float, default=0.8, help="rad de inclinacion que se considera caida")
    ap.add_argument("--dry-run", action="store_true", help="no camina: solo estima y muestra")
    ap.add_argument("--save-frames", type=int, default=0, help="guardar 1 de cada N imagenes (0 = no)")
    ap.add_argument("--max-saved", type=int, default=400)
    ap.add_argument("--log-dir", default=os.path.join(HERE, "logs"))
    args = ap.parse_args()

    cam = CameraModel(320, 240, args.hfov, args.vfov)
    est = LaneEstimator(cam, dark_ratio=args.dark_ratio, min_contrast=args.min_contrast, color_order="rgb")
    filt = LaneFilter()
    ctrl = LaneController(vx_max=args.vx)
    gait = [["MaxStepX", args.max_step_x], ["MaxStepFrequency", args.step_freq]]

    io = NaoIO(args.ip, args.port, args.fps, args.head_pitch)
    hold = HoldDetector(io)
    log = Logger(args.log_dir)
    frames, poses = [], []
    state = "ESPERA"
    print("Log:", log.path)
    try:
        if not args.dry_run:
            io.stand()
        else:
            io.look_down()
        print("Listo. Tactil FRONTAL de la cabeza 0.25 s = arrancar | boton del PECHO 0.3 s = detener.")
        t_start = None
        last_ok = time.time()
        last_cmd = 0.0
        last_print = 0.0
        finish_s = None
        cmd = (0.0, 0.0, 0.0)
        n_img = 0
        while True:
            now = time.time()
            # ---------------- vision (siempre, tambien en la espera: el filtro llega inicializado)
            img, T = io.image()
            ms = 0.0
            e = None
            if img is not None:
                t0 = time.time()
                e = est.process(img, T)
                ms = 1000.0 * (time.time() - t0)
                n_img += 1
                if args.save_frames and n_img % args.save_frames == 0 and len(frames) < args.max_saved:
                    frames.append(img.copy())
                    poses.append(T.copy())
            dx, dy, dth = io.odom_delta()
            filt.predict(dx, dy, dth)
            if e is not None and filt.update(e):
                last_ok = now

            # ---------------- maquina de estados
            if hold.held(KEY_ABORT, ABORT_HOLD_S, now):
                print("Paro manual (boton del pecho 0.3 s).")
                state = "PARO"
                break
            if state == "ESPERA":
                if hold.held(KEY_START, START_HOLD_S, now):
                    state = "CARRERA"
                    t_start = now
                    filt.s = 0.0
                    print("ARRANQUE")
            elif state == "CARRERA":
                t_run = now - t_start
                if io.tilt() > args.fall_tilt:
                    print("Caida detectada en t=%.1f s: levantandose" % t_run)
                    io.get_up()
                    filt.P_d, filt.P_psi = 1.0, 1.0  # aceptar de nuevo la vision
                    continue
                if e is not None and e.red_dist is not None and e.red_dist < args.finish_trigger and finish_s is None:
                    finish_s = filt.s + args.post_finish
                    print("Meta a la vista (%.2f m) en t=%.1f s" % (e.red_dist, t_run))
                done = ((finish_s is not None and filt.s >= finish_s) or filt.s > args.max_distance
                        or t_run > args.time_limit)
                if done:
                    state = "META"
                    break
                if now - last_cmd >= 0.1:
                    conf = 1.0 if now - last_ok < args.lost_timeout else 0.0
                    cmd = ctrl.command(filt.d, filt.psi, conf)
                    if not args.dry_run:
                        io.move(cmd[0], cmd[1], cmd[2], gait)
                    last_cmd = now

            log.row(t=(now - t_start) if t_start else 0.0, estado=state,
                    valido=int(bool(e is not None and e.valid)), lineas=(e.n_lines if e is not None else 0),
                    d_vis=(e.d if e is not None and e.valid else ""), psi_vis=(e.psi if e is not None and e.valid else ""),
                    red_dist=(e.red_dist if e is not None and e.red_dist is not None else ""),
                    d=filt.d, psi=filt.psi, s=filt.s, sigma_d=filt.sigma_d,
                    vx=float(cmd[0]), vy=float(cmd[1]), vth=float(cmd[2]), margen=ctrl.margin(filt.d), ms_vision=ms)
            if now - last_print > 0.5:
                last_print = now
                print("%-8s d=%+.3f m psi=%+5.1f deg s=%.2f m margen=%.2f m lineas=%s vision=%.1f ms"
                      % (state, filt.d, math.degrees(filt.psi), filt.s, ctrl.margin(filt.d),
                         e.n_lines if e is not None else "-", ms))
    except KeyboardInterrupt:
        print("Interrumpido.")
    finally:
        io.stop()
        io.close()
        log.close()
        if frames:
            out = os.path.join(args.log_dir, time.strftime("frames_%Y%m%d_%H%M%S.npz"))
            np.savez_compressed(out, frames=np.array(frames), poses=np.array(poses),
                                hfov=args.hfov, vfov=args.vfov)
            print("Imagenes guardadas en", out)
        print("Fin:", state)


if __name__ == "__main__":
    main()

# `camara/`: visión de carril (Fase P, propuesta de método para el paso 70)

Justificación completa, resultados y cómo encaja en el plan: [`docs/fase_p_camara.md`](../docs/fase_p_camara.md).

Esta carpeta es **independiente del entrenamiento**: no modifica `src/` ni `configs/`, así que no bloquea las fases J a O. La política actual solo se usa para la demo en lazo cerrado.

## Qué hay

| Ruta | Qué es | Dónde corre |
|---|---|---|
| `carril/lane_estimator.py` | Estimador de carril con numpy: líneas negras → nube de puntos en el piso → rectas → `d`, `psi`, válido, distancia a la meta roja | PC y NAO (si tiene numpy) |
| `carril/lane_estimator_puro.py` | El mismo estimador en **Python puro**, sin dependencias (escrito para Python 2.7 y 3; probado en 3) | NAO sin numpy |
| `carril/camera_model.py` | Cámara pinhole del NAO y proyección píxel → suelo | PC y NAO |
| `carril/lane_filter.py` | Filtro de Kalman: visión + odometría (Python puro) | PC y NAO |
| `carril/controller.py` | Corrección de rumbo para la caminata nativa (Python puro) | PC y NAO |
| `robot/race_nao.py` | **Prototipo** a bordo con NAOqi para medir la visión en la pista real (`--dry-run`) | NAO |
| `robot/replay.py` | Reprocesa en el PC las imágenes grabadas en el robot para ajustar umbrales | PC |
| `demo/build_scene.py` | Genera la pista de 5 m × 70 cm en MuJoCo y el NAO con su cámara inferior | PC |
| `demo/run_demo.py` | Demo interactiva: política RL actual con y sin visión, con la vista de la cámara del robot | PC |
| `demo/figura_*.py` | Figuras de `docs/img/fase_p_*.png` | PC |
| `pruebas/` | Pruebas con imágenes sintéticas, estrés, modelo de error, Python puro vs numpy, lazo cerrado y NAOqi falso | PC |

## Comandos (desde la raíz del repo)

```bash
uv run python camara/demo/build_scene.py                 # pista (assets/nao/scene_carril.xml); ya viene generada
uv run python camara/demo/run_demo.py --live             # demo interactiva con panel (posición inicial, visión sí/no, Correr)
uv run python camara/demo/run_demo.py --video demo.mp4 --inicio-d 10 --inicio-psi 8   # video comparativo

uv run python camara/pruebas/synthetic.py --n 300        # precisión con imágenes sintéticas
uv run python camara/pruebas/stress_vision.py            # condiciones difíciles
uv run python camara/pruebas/modelo_error.py             # -> results/camara/modelo_error.md (valores para el paso 71)
uv run python camara/pruebas/comparar_puro.py            # -> results/camara/estimador_puro.md
uv run python camara/pruebas/evaluar_lazo_cerrado.py     # -> results/camara/lazo_cerrado.md (~25 min)
```

- **macOS:** el visor necesita `mjpython`.
- **Linux sin pantalla:** anteponer `MUJOCO_GL=egl` (u `osmesa`).

## En el robot (prototipo, paso 70)

1. Copiar `camara/carril/` y `camara/robot/race_nao.py` por Ethernet.
2. Correr `python race_nao.py --dry-run --save-frames 2` con el robot en la pista réplica.
3. Comparar `d` y `psi` con cinta métrica.
4. Revisar las imágenes en el PC con `robot/replay.py`.

**No correrlo junto al proceso `bhuman`.** La integración definitiva va en PenaltyStack (pasos 64 y 72).

# -*- coding: utf-8 -*-
"""Prueba de estres del detector de carril en condiciones dificiles (PC, Python 3).

Uso:  uv run python camara/pruebas/stress_vision.py [--n 120]
"""
from __future__ import division, print_function

import argparse
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from carril import CameraModel, LaneEstimator  # noqa: E402
from synthetic import render, camera_T, CAM_Z  # noqa: E402


def blur(img, k, axis):
    out = np.zeros_like(img, dtype=float)
    for s in range(-(k // 2), k // 2 + 1):
        out += np.roll(img.astype(float), s, axis=axis)
    return out / k


def glare(img, rng, n=3):
    h, w = img.shape[:2]
    vv, uu = np.mgrid[0:h, 0:w]
    out = img.astype(float)
    for _ in range(n):
        cu, cv, r = rng.uniform(0, w), rng.uniform(h * 0.3, h), rng.uniform(15, 45)
        out += 140 * np.exp(-((uu - cu) ** 2 + (vv - cv) ** 2) / (2 * r * r))[..., None]
    return out


def occlude(img, rng):
    """Robot vecino (blanco/gris) tapando parte de un lado de la imagen."""
    h, w = img.shape[:2]
    out = img.astype(float).copy()
    side = rng.choice([0, 1])
    u0 = int(rng.uniform(0, w * 0.25)) if side == 0 else int(rng.uniform(w * 0.6, w * 0.85))
    out[: int(h * rng.uniform(0.4, 0.8)), u0:u0 + int(w * 0.25)] = rng.uniform(170, 220)
    return out


def worn(img, rng, frac=0.35):
    """Cinta gastada o tapada: parches del color del piso sobre la linea."""
    h, w = img.shape[:2]
    out = img.astype(float).copy()
    med = np.median(img.reshape(-1, 3), axis=0)
    for _ in range(int(frac * 25)):
        v0 = int(rng.uniform(0, h - 10))
        band = out[v0:v0 + 8]
        dark = band.mean(axis=-1) < 70
        band[dark] = med
    return out


CONDITIONS = {
    "base": lambda img, rng: img,
    "desenfoque de movimiento": lambda img, rng: blur(img, 7, axis=0),
    "poca luz (x0.35 + ruido)": lambda img, rng: img * 0.35 + rng.normal(0, 8, img.shape),
    "sobreexpuesta (x1.7)": lambda img, rng: img * 1.7,
    "reflejos en la duela": glare,
    "robot vecino tapando": occlude,
    "cinta gastada (35%)": worn,
}


def evaluate(n, cond, pose_err_deg=1.5, roll_amp_deg=4.0, seed=5, **est_kw):
    rng = np.random.RandomState(seed)
    cam = CameraModel(320, 240)
    est = LaneEstimator(cam, **est_kw)
    errs, invalid, outliers = [], 0, 0
    for i in range(n):
        d = rng.uniform(-0.22, 0.22)
        psi = math.radians(rng.uniform(-20, 20))
        roll_t, pitch_t = math.radians(rng.uniform(-roll_amp_deg, roll_amp_deg)), math.radians(rng.uniform(-4, 4))
        T_true = camera_T(pitch_t, roll_t, z=CAM_Z)
        T_meas = camera_T(pitch_t + math.radians(rng.normal(0, pose_err_deg)),
                          roll_t + math.radians(rng.normal(0, pose_err_deg)), z=CAM_Z + rng.normal(0, 0.01))
        img = render(cam, T_true, d, psi, s0=rng.uniform(0.5, 4), rng=rng, wood_dark=(i % 3 == 0), ss=1)
        img = np.clip(CONDITIONS[cond](img, rng), 0, 255).astype(np.uint8)
        e = est.process(img, T_meas)
        if not e.valid:
            invalid += 1
            continue
        err = abs(e.d - d)
        errs.append(err)
        outliers += err > 0.06 or abs(e.psi - psi) > math.radians(6)
    errs = np.array(errs) if errs else np.array([np.nan])
    return dict(valid=100.0 * (n - invalid) / n, mae=100 * np.nanmean(errs), p95=100 * np.nanpercentile(errs, 95),
                outl=100.0 * outliers / n)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=120)
    a = ap.parse_args()
    print("%-30s %8s %10s %10s %14s" % ("condicion", "validas", "err d", "p95 d", "errores >6cm"))
    for c in CONDITIONS:
        r = evaluate(a.n, c)
        print("%-30s %7.0f%% %8.1f cm %8.1f cm %12.0f%%" % (c, r["valid"], r["mae"], r["p95"], r["outl"]))
    for label, kw in (("error de pose 3 deg", dict(pose_err_deg=3.0)), ("balanceo +-8 deg", dict(roll_amp_deg=8.0))):
        r = evaluate(a.n, "base", **kw)
        print("%-30s %7.0f%% %8.1f cm %8.1f cm %12.0f%%" % (label, r["valid"], r["mae"], r["p95"], r["outl"]))

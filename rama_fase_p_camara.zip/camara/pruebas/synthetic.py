# -*- coding: utf-8 -*-
"""Prueba del estimador con imagenes sinteticas del carril (corre en el PC, Python 3).

Renderiza lo que veria la camara inferior del NAO de pie sobre un carril de 70 cm con lineas negras de
1.9 cm sobre duela de madera (veta, ruido, cambio de iluminacion), con carriles vecinos, franja de salida
y franja roja de meta. Al estimador se le entrega una pose de camara con error (balanceo de la caminata).

Uso:  uv run python camara/pruebas/synthetic.py [--n 300] [--save-examples carpeta]
"""
from __future__ import division, print_function

import argparse
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from carril import CameraModel, LaneEstimator, make_transform  # noqa: E402

LANE = 0.70
LINE = 0.019
SPACING = LANE + LINE

# Pose nominal de la camara inferior con el NAO de pie (StandInit) y HeadPitch = 0:
# altura ~0.46 m, ~5 cm por delante del origen, inclinada 39.7 grados hacia abajo.
CAM_X, CAM_Z, CAM_PITCH = 0.05, 0.46, math.radians(39.7)


def render(cam, T, d, psi, s0=1.0, finish_at=None, start_at=None, rng=None, ss=2, wood_dark=False):
    """Imagen BGR uint8. d, psi: pose del robot respecto al carril; s0: avance del robot en el carril [m]."""
    rng = rng or np.random.RandomState(0)
    w, h = cam.width * ss, cam.height * ss
    big = CameraModel(w, h)
    big.fx, big.fy = cam.fx * ss, cam.fy * ss
    big.cx, big.cy = (w - 1) / 2.0, (h - 1) / 2.0
    uu, vv = np.meshgrid(np.arange(w, dtype=float), np.arange(h, dtype=float))
    x, y, _, valid = big.pixels_to_ground(uu, vv, T)
    x = np.where(valid, x, 1e3)
    y = np.where(valid, y, 0)
    # marco del carril: Y lateral (+ izquierda del centro), X a lo largo
    Y = d + x * math.sin(psi) + y * math.cos(psi)
    X = s0 + x * math.cos(psi) - y * math.sin(psi)
    # duela: tablas de 9 cm a lo largo de X con tonos distintos + veta + juntas
    plank = np.floor(Y / 0.09)
    tone = (np.sin(plank * 12.9898) * 43758.5453) % 1.0
    grain = 0.5 + 0.5 * np.sin(Y * 380.0 + 3.0 * np.sin(X * 2.1 + plank))
    base = np.array([95.0, 150.0, 200.0]) if not wood_dark else np.array([55.0, 85.0, 125.0])  # BGR
    lum = 0.82 + 0.18 * tone[..., None] - 0.10 * grain[..., None]
    img = base[None, None, :] * lum
    joint = (np.abs(Y / 0.09 - np.round(Y / 0.09)) * 0.09) < 0.0015
    img[joint] *= 0.7
    # lineas negras: propio carril y vecinos
    black = np.zeros_like(Y, dtype=bool)
    for k in (-2, -1, 0, 1):
        yl = (k + 0.5) * SPACING
        black |= np.abs(Y - yl) < LINE / 2
    if start_at is not None:
        black |= (X > start_at) & (X < start_at + 0.18)
    img[black] = [28.0, 28.0, 30.0]
    if finish_at is not None:
        red = (X > finish_at) & (X < finish_at + 0.30) & (np.abs(Y) < LANE / 2)
        img[red] = [40.0, 35.0, 185.0]
    img[~valid] = [180.0, 180.0, 180.0]  # pared/fondo (no deberia pasar mirando al suelo)
    # iluminacion no uniforme + ruido
    grad = 0.85 + 0.3 * (uu / w)
    img *= grad[..., None]
    if ss > 1:
        img = img.reshape(cam.height, ss, cam.width, ss, 3).mean(axis=(1, 3))
    img += rng.normal(0, 6.0, img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)


def camera_T(head_pitch=0.0, roll=0.0, sway_y=0.0, z=CAM_Z):
    return make_transform(CAM_X, sway_y, z, roll=roll, pitch=CAM_PITCH + head_pitch)


def run(n, save_dir=None, seed=1):
    rng = np.random.RandomState(seed)
    cam = CameraModel(320, 240)
    est = LaneEstimator(cam)
    errs_d, errs_psi, two_lines, fails, times = [], [], 0, 0, []
    rows = []
    for i in range(n):
        d = rng.uniform(-0.22, 0.22)
        psi = math.radians(rng.uniform(-20, 20))
        # pose real con balanceo de la caminata
        roll_t = math.radians(rng.uniform(-4, 4))
        pitch_t = math.radians(rng.uniform(-4, 4))
        z_t = CAM_Z + rng.uniform(-0.01, 0.01)
        T_true = camera_T(pitch_t, roll_t, z=z_t)
        # pose que conoce el estimador (sensores): error residual de 1.5 grados y 1 cm
        T_meas = camera_T(pitch_t + math.radians(rng.normal(0, 1.5)), roll_t + math.radians(rng.normal(0, 1.5)),
                          z=z_t + rng.normal(0, 0.01))
        img = render(cam, T_true, d, psi, s0=rng.uniform(0.5, 4), rng=rng, wood_dark=(i % 3 == 0))
        t0 = time.perf_counter()
        e = est.process(img, T_meas)
        times.append(time.perf_counter() - t0)
        if not e.valid:
            fails += 1
            rows.append((d, psi, None, None, 0))
            continue
        two_lines += e.n_lines == 2
        errs_d.append(e.d - d)
        errs_psi.append(e.psi - psi)
        rows.append((d, psi, e.d, e.psi, e.n_lines))
        if save_dir and i < 6:
            save_example(save_dir, i, img, est, e, d, psi)
    ed, ep = np.abs(errs_d), np.degrees(np.abs(errs_psi))
    print("Muestras: %d  | validas: %d (%.1f%%) | con 2 lineas: %d" % (n, n - fails, 100.0 * (n - fails) / n, two_lines))
    print("Error lateral d   : media %.1f cm | p95 %.1f cm | max %.1f cm" % (100 * ed.mean(), 100 * np.percentile(ed, 95), 100 * ed.max()))
    print("Error de rumbo psi: media %.2f deg | p95 %.2f deg | max %.2f deg" % (ep.mean(), np.percentile(ep, 95), ep.max()))
    print("Tiempo por imagen : media %.2f ms | p95 %.2f ms (en este PC)" % (1e3 * np.mean(times), 1e3 * np.percentile(times, 95)))
    return rows


def scenario_tests():
    """Casos especiales: arranque sobre la franja de salida, meta roja, robot cerca del borde."""
    cam = CameraModel(320, 240)
    est = LaneEstimator(cam)
    T = camera_T()
    rng = np.random.RandomState(7)
    print("\nEscenarios:")
    # 1) en la salida: franja negra perpendicular bajo/delante de los pies
    img = render(cam, T, 0.03, math.radians(3), s0=0.0, start_at=-0.09, rng=rng)
    e = est.process(img, T)
    print("  En la franja de salida   : valido=%s d=%+.3f (real +0.030) psi=%+.1f deg (real +3.0) lineas=%d"
          % (e.valid, e.d, math.degrees(e.psi), e.n_lines))
    # 2) cerca del borde izquierdo
    img = render(cam, T, 0.20, math.radians(-8), rng=rng)
    e = est.process(img, T)
    print("  Cerca del borde (d=0.20) : valido=%s d=%+.3f psi=%+.1f deg (real -8.0) lineas=%d"
          % (e.valid, e.d, math.degrees(e.psi), e.n_lines))
    # 3) meta roja a distintas distancias
    for dist in (1.2, 0.8, 0.5, 0.3):
        img = render(cam, T, 0.0, 0.0, s0=0.0, finish_at=dist, rng=rng)
        e = est.process(img, T)
        rd = "no vista" if e.red_dist is None else "%.2f m" % e.red_dist
        print("  Meta roja a %.1f m        : distancia estimada %s | carril valido=%s d=%+.3f" % (dist, rd, e.valid, e.d))
    # 4) sin meta: falsos positivos de rojo sobre madera oscura
    fp = 0
    for k in range(40):
        img = render(cam, T, rng.uniform(-0.2, 0.2), math.radians(rng.uniform(-15, 15)), rng=rng, wood_dark=bool(k % 2))
        fp += est.process(img, T).red_dist is not None
    print("  Falsos positivos de meta : %d / 40" % fp)


def save_example(folder, i, img, est, e, d, psi):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    if not os.path.isdir(folder):
        os.makedirs(folder)
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
    ax[0].imshow(img[:, :, ::-1])
    ax[0].set_title("Camara inferior (sintetica)")
    ax[0].axis("off")
    p = est.last_points
    ax[1].scatter(p[:, 1], p[:, 0], s=4, c="k", label="puntos de linea")
    xs = np.linspace(0.1, 2.0, 20)
    for c in (e.c_left, e.c_right):
        if c is not None:
            ax[1].plot(c + e.slope * xs, xs, "r-")
    ax[1].plot([0], [0], "b^", ms=10, label="robot")
    ax[1].invert_xaxis()
    ax[1].set_xlabel("y [m] (izquierda +)")
    ax[1].set_ylabel("x [m] (adelante)")
    ax[1].set_title("real d=%+.2f psi=%+.0f | est d=%+.2f psi=%+.0f" % (d, math.degrees(psi), e.d, math.degrees(e.psi)))
    ax[1].legend(loc="upper right", fontsize=7)
    ax[1].set_aspect("equal")
    fig.tight_layout()
    fig.savefig(os.path.join(folder, "ejemplo_%d.png" % i), dpi=90)
    plt.close(fig)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--save-examples", default=None)
    a = ap.parse_args()
    run(a.n, a.save_examples)
    scenario_tests()

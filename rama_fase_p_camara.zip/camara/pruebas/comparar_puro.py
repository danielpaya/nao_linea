# -*- coding: utf-8 -*-
"""Compara el estimador en Python puro (lane_estimator_puro.py) con el de numpy y mide su tiempo.

Uso (desde la raiz del repo):  uv run python camara/pruebas/comparar_puro.py [--n 60]
Guarda results/camara/estimador_puro.md.
"""
from __future__ import division, print_function

import argparse
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
from carril import CameraModel, LaneEstimator  # noqa: E402
from carril.lane_estimator_puro import EstimadorCarrilPuro  # noqa: E402
from synthetic import render, camera_T  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=60)
    a = ap.parse_args()
    rng = np.random.RandomState(11)
    cam = CameraModel(320, 240)
    est_np = LaneEstimator(cam, color_order="rgb")
    est_py = EstimadorCarrilPuro(color_order="rgb")
    err_np, err_py, dif, t_np, t_py, red_ok = [], [], [], [], [], 0
    for i in range(a.n):
        d = rng.uniform(-0.2, 0.2)
        psi = math.radians(rng.uniform(-15, 15))
        T = camera_T(math.radians(rng.uniform(-3, 3)), math.radians(rng.uniform(-3, 3)))
        fin = 0.6 if i % 5 == 0 else None
        img = render(cam, T, d, psi, s0=1.0 if fin is None else 0.0, finish_at=fin, rng=rng, wood_dark=bool(i % 3 == 0), ss=1)
        rgb = np.ascontiguousarray(img[:, :, ::-1])
        data = rgb.tobytes()                       # como llega de ALVideoDevice
        T16 = [float(v) for v in T.flatten()]      # como llega de ALMotion.getTransform
        t0 = time.perf_counter(); e1 = est_np.process(rgb, T); t_np.append(time.perf_counter() - t0)
        t0 = time.perf_counter(); e2 = est_py.procesar(data, T16); t_py.append(time.perf_counter() - t0)
        if e1.valid and e2.valid:
            err_np.append(abs(e1.d - d)); err_py.append(abs(e2.d - d)); dif.append(abs(e1.d - e2.d))
        if fin is not None and e2.red_dist is not None and abs(e2.red_dist - fin) < 0.08:
            red_ok += 1
    n_red = len([i for i in range(a.n) if i % 5 == 0])
    lines = [
        "# Estimador en Python puro vs numpy", "",
        "Generado por `camara/pruebas/comparar_puro.py` con %d imagenes sinteticas (QVGA RGB, error de pose 0)." % a.n, "",
        "| | numpy (`lane_estimator.py`) | Python puro (`lane_estimator_puro.py`) |", "|---|---|---|",
        "| Error lateral medio | %.1f cm | %.1f cm |" % (100 * np.mean(err_np), 100 * np.mean(err_py)),
        "| Tiempo por imagen en este PC (%s) | %.1f ms | %.1f ms |" % (os.uname().machine if hasattr(os, "uname") else "?", 1e3 * np.mean(t_np), 1e3 * np.mean(t_py)),
        "| Meta roja detectada (+-8 cm) | — | %d / %d |" % (red_ok, n_red), "",
        "Diferencia media entre ambos estimadores: %.1f cm." % (100 * np.mean(dif)), "",
        "En el NAO V6 (Intel Atom E3845) se espera un tiempo de 3 a 8 veces mayor que en un PC de escritorio "
        "**(a validar en la sesion 1, paso 65)**. Con la camara a 10 FPS hay 100 ms por imagen.",
    ]
    out = os.path.join(HERE, "..", "..", "results", "camara")
    if not os.path.isdir(out):
        os.makedirs(out)
    with open(os.path.join(out, "estimador_puro.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

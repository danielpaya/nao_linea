# -*- coding: utf-8 -*-
"""NAOqi falso para probar race_nao.py en el PC, sin robot.

Simula: camara inferior (imagen sintetica del carril), odometria, moveToward con deriva de rumbo,
botones de la cabeza (arranque automatico al segundo 1) y una caida a los 8 s.

Uso (desde la raiz del repo):
    PYTHONPATH=camara/pruebas/fake_naoqi:camara/pruebas:camara uv run python camara/robot/race_nao.py --log-dir /tmp/logs
"""
from __future__ import division

import math
import time

import numpy as np

from synthetic import render, camera_T
from carril import CameraModel

VX_MAX, VY_MAX, WZ_MAX = 0.12, 0.05, 0.5
SPEEDUP = 4.0  # el tiempo simulado corre 4 veces mas rapido que el real


class _World(object):
    def __init__(self):
        self.rng = np.random.RandomState(3)
        self.d, self.psi, self.s = 0.04, math.radians(-3), 0.0
        self.x = self.y = self.th = 0.0
        self.cmd = (0.0, 0.0, 0.0)
        self.t_real0 = time.time()
        self.t_sim = 0.0
        self.drift = math.radians(3.0)
        self.fallen_until = None
        self.fell = False
        self.cam = CameraModel(320, 240)

    def advance(self):
        t = (time.time() - self.t_real0) * SPEEDUP
        dt_total = t - self.t_sim
        while dt_total > 1e-6:
            dt = min(0.02, dt_total)
            vx, vy, wz = self.cmd[0] * VX_MAX, self.cmd[1] * VY_MAX, self.cmd[2] * WZ_MAX
            if vx or vy or wz:
                wz_r = wz + self.drift + self.rng.normal(0, 0.05)
                self.d += (vx * math.sin(self.psi) + vy * math.cos(self.psi)) * dt
                self.s += (vx * math.cos(self.psi) - vy * math.sin(self.psi)) * dt
                self.psi += wz_r * dt
                self.x += (vx * math.cos(self.th) - vy * math.sin(self.th)) * dt * 1.1
                self.y += (vx * math.sin(self.th) + vy * math.cos(self.th)) * dt * 1.1
                self.th += wz * dt * 0.9
            self.t_sim += dt
            dt_total -= dt


W = _World()


class ALProxy(object):
    def __init__(self, name, ip=None, port=None):
        self.name = name

    # ALMotion
    def wakeUp(self): pass
    def moveInit(self): pass
    def setStiffnesses(self, *a): pass
    def setAngles(self, *a): pass

    def moveToward(self, vx, vy, vth, cfg=None):
        W.advance()
        W.cmd = (vx, vy, vth)

    def stopMove(self):
        W.advance()
        W.cmd = (0.0, 0.0, 0.0)

    def getRobotPosition(self, use_sensors):
        W.advance()
        return [W.x, W.y, W.th]

    def getTransform(self, name, frame, use_sensors):
        roll = math.radians(3.0 * math.sin(2 * math.pi * W.t_sim / 0.6)) if any(W.cmd) else 0.0
        return list(camera_T(0.0, roll).flatten())

    # ALRobotPosture
    def goToPosture(self, name, speed):
        time.sleep(0.2)
        return True

    # ALVideoDevice
    def getSubscribers(self): return []
    def subscribeCamera(self, *a): return "carril_0"
    def unsubscribe(self, h): pass

    def getImageRemote(self, handle):
        W.advance()
        img = render(W.cam, camera_T(), W.d, W.psi, s0=W.s, finish_at=5.0, start_at=-0.09, rng=W.rng, ss=1)
        return [320, 240, 3, 11, 0, 0, img[:, :, ::-1].tobytes()]   # RGB, como PenaltyStack

    # ALMemory
    def getData(self, key):
        W.advance()
        if key.endswith("Head/Touch/Front/Sensor/Value"):
            return 1.0 if 1.0 < W.t_sim < 2.5 else 0.0
        if key.endswith("ChestBoard/Button/Sensor/Value"):
            return 0.0
        if key.endswith("AngleY/Sensor/Value"):
            if not W.fell and W.t_sim > 8.0:
                W.fell = True
                W.cmd = (0.0, 0.0, 0.0)
                return 1.4
            return 0.0
        return 0.0

    # ALAutonomousLife
    def setState(self, s): pass

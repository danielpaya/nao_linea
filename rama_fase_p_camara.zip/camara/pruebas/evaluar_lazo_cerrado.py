# -*- coding: utf-8 -*-
"""Evaluacion sistematica en MuJoCo: politica RL actual con y sin vision de carril.

Para cada colocacion inicial (desplazamiento lateral x rumbo, los rangos de la seccion 5.5 de
docs/plan_rl_carrera.md) y cada semilla, corre la carrera de 5 m dos veces: solo RL y RL + vision.
Guarda results/camara/lazo_cerrado.json y results/camara/lazo_cerrado.md.

Uso (desde la raiz del repo):
    uv run python camara/pruebas/evaluar_lazo_cerrado.py
En Linux sin pantalla: MUJOCO_GL=egl (u osmesa) delante.
"""
import itertools
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "camara" / "demo"))
import run_demo as R  # noqa: E402

D_CM = (-10, 0, 10)
PSI_DEG = (-8, 0, 8)
SEEDS = (1000, 1001)


def main():
    out_dir = ROOT / "results" / "camara"
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    t0 = time.time()
    for d_cm, psi, seed in itertools.product(D_CM, PSI_DEG, SEEDS):
        for vision in (False, True):
            info, _, _ = R.run(vision, seed=seed, start_d=d_cm / 100.0, start_psi_deg=psi, log=lambda *a: None)
            rows.append(dict(inicio_d_cm=d_cm, inicio_psi_deg=psi, semilla=seed, vision=vision,
                             resultado=info["result"], tiempo_s=round(info["t"], 2), avance_m=round(info["x"], 3),
                             desvio_max_cm=round(100 * info["max_d"], 1)))
            print("d=%+3d cm psi=%+2d seed=%d %-12s -> %-17s %5.1f s  avance %.2f m  desvio max %.1f cm"
                  % (d_cm, psi, seed, "RL + vision" if vision else "solo RL", info["result"], info["t"], info["x"],
                     100 * info["max_d"]), flush=True)
    try:
        commit = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT).decode().strip()
    except Exception:  # noqa: BLE001
        commit = "?"
    meta = dict(fecha=time.strftime("%Y-%m-%d %H:%M"), commit=commit, maquina=platform.node(),
                python=platform.python_version(), politica="checkpoints/best_model.zip (sprint inicial, V2 brazos)",
                error_pose_camara_deg=1.0, duracion_s=round(time.time() - t0, 1))
    (out_dir / "lazo_cerrado.json").write_text(json.dumps(dict(meta=meta, corridas=rows), indent=2, ensure_ascii=False))

    def summary(vision):
        sel = [r for r in rows if r["vision"] == vision]
        meta_ok = [r for r in sel if r["resultado"] == "META"]
        return (len(meta_ok), len(sel), max(r["desvio_max_cm"] for r in sel),
                sum(r["desvio_max_cm"] for r in sel) / len(sel),
                (sum(r["tiempo_s"] for r in meta_ok) / len(meta_ok)) if meta_ok else float("nan"))

    lines = ["# Lazo cerrado en MuJoCo: politica RL actual con y sin vision de carril", "",
             "Generado por `camara/pruebas/evaluar_lazo_cerrado.py` (%s, commit `%s`, maquina `%s`)."
             % (meta["fecha"], commit, meta["maquina"]), "",
             "- Politica: `%s`, sin reentrenar." % meta["politica"],
             "- Pista: 5 m x 70 cm (`assets/nao/scene_carril.xml`). Salida de carril: el borde exterior de un pie cruza el borde interior de la linea (el desvio maximo de las corridas que se salen queda en ~26 cm).",
             "- Vision: camara inferior simulada (QVGA, 54.7 x 42.5 grados), error de pose de la camara de 1 grado, odometria con 10 % de error.",
             "- Correccion de rumbo: sesgo en la observacion del giroscopio (truco de demostracion, ver docs/fase_p_camara.md).", "",
             "| | Llegan a la meta | Desvio max. (peor) | Desvio max. (medio) | Tiempo medio en 5 m |", "|---|---|---|---|---|"]
    for vision, name in ((False, "Solo RL"), (True, "RL + vision")):
        ok, n, worst, mean, tmean = summary(vision)
        lines.append("| %s | **%d / %d** | %.1f cm | %.1f cm | %.1f s |" % (name, ok, n, worst, mean, tmean))
    lines += ["", "## Detalle", "", "| Inicio d [cm] | Inicio rumbo [grados] | Semilla | Solo RL | RL + vision |", "|---|---|---|---|---|"]
    for d_cm, psi, seed in itertools.product(D_CM, PSI_DEG, SEEDS):
        a = [r for r in rows if (r["inicio_d_cm"], r["inicio_psi_deg"], r["semilla"]) == (d_cm, psi, seed)]
        cell = lambda r: "%s (%.0f cm)" % ("meta %.1f s" % r["tiempo_s"] if r["resultado"] == "META" else r["resultado"].lower() + " a %.2f m" % r["avance_m"], r["desvio_max_cm"])  # noqa: E731
        lines.append("| %+d | %+d | %d | %s | %s |" % (d_cm, psi, seed, cell(a[0]), cell(a[1])))
    (out_dir / "lazo_cerrado.md").write_text("\n".join(lines) + "\n")
    print("Guardado en", out_dir)


if __name__ == "__main__":
    main()

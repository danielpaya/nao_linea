# -*- coding: utf-8 -*-
"""Modelo de error de la vision de carril: los numeros que necesita el paso 71 del PLAN.

El paso 71 simula la salida de la camara como  valor real + ruido gaussiano + retardo + perdidas  a 10 Hz.
Este script mide en imagenes sinteticas: sesgo, desviacion estandar (sigma) y p95 del error de d y psi,
porcentaje de mediciones invalidas (perdidas) y de mediciones malas (> 6 cm o > 6 grados), en funcion
del error de la pose de la camara y de condiciones dificiles.

Uso (desde la raiz del repo):  uv run python camara/pruebas/modelo_error.py [--n 150]
Guarda results/camara/modelo_error.json y results/camara/modelo_error.md.
"""
from __future__ import division, print_function

import argparse
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
from carril import CameraModel, LaneEstimator  # noqa: E402
from synthetic import render, camera_T, CAM_Z  # noqa: E402
from stress_vision import CONDITIONS  # noqa: E402


def measure(n, cond="base", pose_err_deg=1.5, seed=21):
    rng = np.random.RandomState(seed)
    cam = CameraModel(320, 240)
    est = LaneEstimator(cam)
    ed, ep, invalid, bad, one_line = [], [], 0, 0, 0
    for i in range(n):
        d = rng.uniform(-0.22, 0.22)
        psi = math.radians(rng.uniform(-20, 20))
        roll_t, pitch_t = math.radians(rng.uniform(-4, 4)), math.radians(rng.uniform(-4, 4))
        T_true = camera_T(pitch_t, roll_t, z=CAM_Z)
        T_meas = camera_T(pitch_t + math.radians(rng.normal(0, pose_err_deg)),
                          roll_t + math.radians(rng.normal(0, pose_err_deg)), z=CAM_Z + rng.normal(0, 0.01))
        img = render(cam, T_true, d, psi, s0=rng.uniform(0.5, 4), rng=rng, wood_dark=(i % 3 == 0), ss=1)
        img = np.clip(CONDITIONS[cond](img, rng), 0, 255).astype(np.uint8)
        e = est.process(img, T_meas)
        if not e.valid:
            invalid += 1
            continue
        one_line += e.n_lines == 1
        ed.append(e.d - d)
        ep.append(math.degrees(e.psi - psi))
        bad += abs(e.d - d) > 0.06 or abs(math.degrees(e.psi - psi)) > 6
    ed, ep = np.array(ed), np.array(ep)
    return dict(condicion=cond, error_pose_deg=pose_err_deg, n=n,
                sesgo_d_cm=round(100 * ed.mean(), 2), sigma_d_cm=round(100 * ed.std(), 2),
                p95_d_cm=round(100 * np.percentile(np.abs(ed), 95), 2),
                sesgo_psi_deg=round(ep.mean(), 2), sigma_psi_deg=round(ep.std(), 2),
                p95_psi_deg=round(np.percentile(np.abs(ep), 95), 2),
                perdidas_pct=round(100.0 * invalid / n, 1), malas_pct=round(100.0 * bad / n, 1),
                una_linea_pct=round(100.0 * one_line / max(1, n - invalid), 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=150)
    a = ap.parse_args()
    rows = [measure(a.n, "base", pe) for pe in (0.0, 0.5, 1.0, 1.5, 2.0, 3.0)]
    rows += [measure(a.n, c, 1.5) for c in CONDITIONS if c != "base"]
    out = os.path.join(HERE, "..", "..", "results", "camara")
    if not os.path.isdir(out):
        os.makedirs(out)
    with open(os.path.join(out, "modelo_error.json"), "w") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)
    hdr = ("| Condicion | Error de pose | Sesgo d | sigma d | p95 d | Sesgo psi | sigma psi | p95 psi | Perdidas | Malas | Una sola linea |\n"
           "|---|---|---|---|---|---|---|---|---|---|---|")
    fmt = "| %s | %.1f deg | %+.2f cm | %.2f cm | %.2f cm | %+.2f deg | %.2f deg | %.2f deg | %.1f %% | %.1f %% | %.0f %% |"
    lines = ["# Modelo de error de la vision de carril (para el paso 71)", "",
             "Generado por `camara/pruebas/modelo_error.py` con %d imagenes sinteticas por fila (d +-22 cm, psi +-20 deg, "
             "balanceo de la camara +-4 deg, madera clara y oscura). *Malas*: error > 6 cm o > 6 deg." % a.n, "", hdr]
    lines += [fmt % (r["condicion"], r["error_pose_deg"], r["sesgo_d_cm"], r["sigma_d_cm"], r["p95_d_cm"], r["sesgo_psi_deg"],
                     r["sigma_psi_deg"], r["p95_psi_deg"], r["perdidas_pct"], r["malas_pct"], r["una_linea_pct"]) for r in rows]
    ref = [r for r in rows if r["condicion"] == "base" and r["error_pose_deg"] == 1.5][0]
    lines += ["", "## Valores propuestos para el paso 71 (a recalibrar con la pista real, paso 70)", "",
              "| Parametro | Valor inicial | De donde sale |", "|---|---|---|",
              "| Frecuencia | 10 Hz, valor mantenido entre fotos | Camara inferior de PenaltyStack (QVGA, RGB, 10 FPS) |",
              "| sigma de d (desplazamiento lateral) | %.1f cm | Fila base con 1.5 deg de error de pose |" % ref["sigma_d_cm"],
              "| sigma de psi (angulo respecto a las lineas) | %.1f deg | Idem |" % ref["sigma_psi_deg"],
              "| Retardo | 100-200 ms | Exposicion y transferencia + 10-110 ms de procesamiento a bordo (a medir) |",
              "| Perdidas | 5-10 %% por foto (repetir el ultimo valor y bajar el indicador de valido) | Mas que lo medido en sintetico (%.1f %%): la pista real es peor |" % ref["perdidas_pct"],
              "| Mediciones malas | 2-5 % con error uniforme de hasta +-15 cm | Robot vecino tapando, reflejos (tabla de arriba) |",
              "| Indicador de valido | 0 si no hay medicion nueva en 300 ms | Contrato v2, seccion 5.1 de docs/plan_rl_carrera.md |"]
    with open(os.path.join(out, "modelo_error.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""Simulacion de lazo cerrado: camara sintetica -> estimador -> filtro -> controlador -> robot cinematico.

El robot simulado tiene una deriva de rumbo constante (como la caminata real o la politica RL, que se
desvian), deslizamiento lateral aleatorio y balanceo de la camara. La odometria NO ve la deriva ni el
deslizamiento (igual que en el NAO). Se mide si cruza los 5 m sin pisar fuera del carril.

Uso:  uv run python camara/pruebas/closed_loop.py [--runs 10] [--no-control]
"""
from __future__ import division, print_function

import argparse
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from carril import CameraModel, LaneEstimator, LaneFilter, LaneController  # noqa: E402
from synthetic import render, camera_T  # noqa: E402

# Velocidades maximas supuestas de moveToward (fraccion 1.0) [VERIFICAR midiendo en el robot]
VX_MAX, VY_MAX, WZ_MAX = 0.12, 0.05, 0.5
DT_CTRL, DT_CAM = 0.1, 1.0 / 15
LANE_LEN, LANE_HALF, FOOT_HALF = 5.0, 0.35, 0.095


def run_once(seed, control=True, drift_deg_s=None):
    rng = np.random.RandomState(seed)
    cam = CameraModel(320, 240)
    est = LaneEstimator(cam, seed=seed)
    filt = LaneFilter()
    ctrl = LaneController()
    d = rng.uniform(-0.05, 0.05)
    psi = math.radians(rng.uniform(-5, 5))
    s = 0.0
    drift = math.radians(drift_deg_s if drift_deg_s is not None else rng.choice([-1, 1]) * rng.uniform(1.5, 4.0))
    t, next_cam, next_ctrl = 0.0, 0.0, 0.0
    cmd = (1.0, 0.0, 0.0) if control else (1.0, 0.0, 0.0)
    max_abs_d, lost = 0.0, 0
    dt = 1.0 / 30
    while s < LANE_LEN and t < 180:
        if t >= next_cam:
            next_cam += DT_CAM
            roll = math.radians(3.0 * math.sin(2 * math.pi * t / 0.6))  # balanceo al ritmo del paso
            T_true = camera_T(math.radians(rng.uniform(-2, 2)), roll)
            T_meas = camera_T(math.radians(rng.normal(0, 1.5)), roll + math.radians(rng.normal(0, 1.5)))
            img = render(cam, T_true, d, psi, s0=s, rng=rng, ss=1, finish_at=LANE_LEN)
            e = est.process(img, T_meas)
            if not filt.update(e):
                lost += 1
        if t >= next_ctrl:
            next_ctrl += DT_CTRL
            if control and filt.initialized:
                cmd = ctrl.command(filt.d, filt.psi)
        vx, vy, wz = cmd[0] * VX_MAX, cmd[1] * VY_MAX, cmd[2] * WZ_MAX
        # dinamica real (con deriva y deslizamiento) y odometria (sin ellos, con 10% de error)
        wz_real = wz + drift + rng.normal(0, 0.05)
        vy_real = vy + rng.normal(0, 0.01)
        d += (vx * math.sin(psi) + vy_real * math.cos(psi)) * dt
        s += (vx * math.cos(psi) - vy_real * math.sin(psi)) * dt
        psi += wz_real * dt
        filt.predict(vx * dt * 1.1, vy * dt, wz * dt * 0.9)
        max_abs_d = max(max_abs_d, abs(d))
        t += dt
        if abs(d) + FOOT_HALF > LANE_HALF + 0.0095:
            return dict(ok=False, t=t, s=s, max_d=max_abs_d, lost=lost, drift=math.degrees(drift))
    return dict(ok=s >= LANE_LEN, t=t, s=s, max_d=max_abs_d, lost=lost, drift=math.degrees(drift))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=10)
    ap.add_argument("--no-control", action="store_true")
    a = ap.parse_args()
    oks = 0
    for k in range(a.runs):
        r = run_once(100 + k, control=not a.no_control)
        oks += r["ok"]
        print("corrida %2d  deriva %+.1f deg/s  %-12s t=%5.1f s  avance=%.2f m  |d| max=%.1f cm  imagenes rechazadas=%d"
              % (k, r["drift"], "META" if r["ok"] else "SALIO DEL CARRIL", r["t"], r["s"], 100 * r["max_d"], r["lost"]))
    print("Completadas: %d/%d" % (oks, a.runs))

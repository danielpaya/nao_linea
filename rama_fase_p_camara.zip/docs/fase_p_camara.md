# Fase P — Método de cámara: visión de carril

**Propuesta para el paso 70 del [`PLAN.md`](../PLAN.md)** ("Definir el método de cámara: qué mide, a qué
frecuencia y con qué error").

- **Autor:** Daniel, con Claude.
- **Rama:** `fase-p-camara-carril`.
- **Fecha:** 2026-10-09.
- **Estado:** validado en simulación. **Falta la medición en la pista real**, que es el criterio de
  aceptación del paso 70.

Código: [`camara/`](../camara/README.md). Resultados: [`results/camara/`](../results/camara/).

---

## Resumen para presentar

1. **El problema que la IMU no puede resolver.** La política sin cámara mantiene el rumbo con el que
   *salió*, no el del carril.
   - Si el robot se coloca **3° chueco** en la salida, en 5 m se desvía **26 cm**, que es prácticamente
     todo el margen.
   - La IMU nunca lo nota.
   - Tampoco puede medir la posición lateral: el propio diseño lo reconoce
     ([`plan_rl_carrera.md`](plan_rl_carrera.md), secciones 5.1 y 6.6).
2. **Lo que propone esta rama.** Un método de cámara que mide exactamente las 3 observaciones que el
   contrato v2 ya reserva:
   - desplazamiento lateral en el carril `d`;
   - ángulo respecto a las líneas `psi`;
   - indicador de medición válida.

   Usa la cámara inferior a 10 FPS, como PenaltyStack.
3. **Precisión (simulación).**
   - σ(d) ≈ **1.6 cm** y σ(psi) ≈ **1.2°** con 1.5° de error en la pose de la cámara.
   - 100 % de mediciones válidas, incluso con poca luz, reflejos o cinta gastada.
4. **Es montable en el NAO.**
   - Hay una versión en **Python puro, sin numpy**, escrita compatible con Python 2.7 (probada en
     Python 3; falta correrla en el 2.7 del NAO).
   - Tarda 13 ms por imagen en PC y unos 40–110 ms estimados en el Atom del NAO, dentro de los 100 ms
     entre fotos.
   - Hay además una versión con numpy unas 7 veces más rápida.
5. **Evidencia en lazo cerrado.** Con la política RL actual y **sin reentrenarla**, en MuJoCo sobre la
   pista de 5 m × 70 cm:

   - **Solo RL:** llega a la meta en **3 de 18** corridas. Son 9 colocaciones iniciales, dentro de los
     rangos de la sección 5.5 del diseño, por 2 semillas. Se sale entre 0.65 y 4.5 m.
   - **RL + visión:** llega en **18 de 18**, con desvío máximo de 14.5 cm y sin perder tiempo: 24.2 s de
     media, frente a 24.8 s de las 3 corridas sin visión que llegaron.

   Detalle: [`results/camara/lazo_cerrado.md`](../results/camara/lazo_cerrado.md).

6. **No compite con el RL, lo completa.** La Fase L (rectitud sin cámara) sigue siendo necesaria para
   minimizar la deriva. La cámara corrige lo que la IMU no puede observar. Juntas permiten pedirle más
   velocidad al RL sin arriesgar la salida del carril.

---

## 1. Por qué no basta con "entrenar al robot para que vaya lo más recto posible"

### 1.1 Lo que pide el reglamento

- Salir del carril **anula la carrera**.
- Hay **un solo intento**.
- El margen lateral es de ~±30 cm descontando el ancho de los pies.

Fuente: [`plan_rl_carrera.md`](plan_rl_carrera.md), sección 1. No basta con ir recto *casi siempre*.

### 1.2 Lo que la política sin cámara puede y no puede ver

La política v1 observa la IMU, las articulaciones y los FSR. Su "error de rumbo" es la diferencia entre
el rumbo actual y el **rumbo de salida** (secciones 5.1 y 5.3 del diseño). Por causa de desvío:

| Causa de desvío | ¿La ve la IMU? | ¿La ve la cámara? |
|---|---|---|
| Asimetría entre piernas que hace girar | Sí, como giro | Sí |
| Empujón de giro | Sí | Sí |
| **Robot colocado chueco en la salida** | **No**: ese rumbo pasa a ser el "objetivo" | **Sí**: mide el ángulo respecto a las líneas |
| **Robot colocado corrido del centro** | **No** | **Sí** |
| **Deslizamiento lateral del pie en la duela** | **No** | **Sí** |
| **Deriva lenta de `AngleZ`** | **No**: es el propio sensor el que deriva | **Sí** |
| Desvío lateral acumulado por pequeños errores de rumbo | **No**: la posición lateral no se observa | **Sí** |

### 1.3 Cuánto se desvía un robot que camina "perfectamente recto" según su IMU

![Deriva sin cámara](img/fase_p_deriva_sin_camara.png)

*Generada con [`camara/demo/figura_deriva.py`](../camara/demo/figura_deriva.py).*

- **(a) Error de colocación.** El operador pone el robot a mano en la franja de salida (reglamento
  3.2.5). En 5 m:
  - 1° de error → 9 cm;
  - 2° → 17 cm;
  - **3° → 26 cm**;
  - 5° → 44 cm, fuera del carril.

  La política sin cámara **no tiene cómo corregirlo**, porque toma ese rumbo como "recto".
- **(b) Giro lento invisible para la IMU**, como la deriva de `AngleZ` o el deslizamiento. A 0.2 m/s:
  - con 1°/s, se sale antes de los 3 m;
  - con 2°/s, antes de los 2 m.

  Cuánto deriva `AngleZ` se mide en la sesión 1 (paso 65).

### 1.4 La evidencia en simulación

La política actual (sprint inicial, sin cámara) evaluada sobre el modelo V6 en la pista de 5 m:

Se probaron 9 colocaciones iniciales por 2 semillas, con la política del sprint inicial y sin
reentrenarla. Las colocaciones son desplazamiento de −10, 0 y +10 cm por rumbo de −8, 0 y +8°, dentro
de los rangos de la sección 5.5 del diseño. Detalle:
[`results/camara/lazo_cerrado.md`](../results/camara/lazo_cerrado.md).

| | Llegan a la meta | Desvío máx. (peor) | Desvío máx. (medio) | Tiempo medio en 5 m |
|---|---|---|---|---|
| Solo RL | **3 / 18** | 27.0 cm (fuera) | 24.9 cm | 24.8 s |
| RL + visión | **18 / 18** | 14.5 cm | 9.0 cm | 24.2 s |

- **Incluso con la salida perfectamente centrada y alineada**, la política sin cámara se salió en 1 de
  las 2 corridas, a los 3.1 m, y en la otra llegó con 23 cm de desvío, al borde del margen.
- **Con 8° de error de colocación**, se sale en el primer metro.

La Fase L va a reducir mucho la deriva de la política. Aun así, lo que no se observa no se puede
corregir: la colocación inicial, el deslizamiento y la deriva del sensor. Por eso la propia sección 6.6
del diseño plantea como meta que la deriva "sea tan pequeña que 5 m no alcancen para salir del carril".
Con la cámara, la meta pasa a ser **no salir nunca**, porque la posición se mide.

---

## 2. El método

![Pasos de la visión](img/fase_p_vision_pasos.png)

*Generada con [`camara/demo/figura_pasos.py`](../camara/demo/figura_pasos.py) sobre la cámara
simulada del NAO. El robot está 10 cm a la izquierda y girado 8°; la estimación da 10.3 cm y 8.0°.*

**Entrada**
- Una imagen de la cámara inferior: QVGA, RGB, 10 FPS, la misma suscripción que PenaltyStack.
- La pose de la cámara respecto al robot en ese instante. Sale de la cinemática del propio NAO:
  `ALMotion.getTransform("CameraBottom", FRAME_ROBOT, True)` o la equivalente de B-Human.

**Pasos**
1. **Buscar la cinta negra.** En 1 de cada 3–4 filas, se marcan los píxeles bastante más oscuros que
   el **fondo local**, una media móvil de 41 px. Comparar con el entorno hace que funcione con poca luz,
   con reflejos y con luz no uniforme.
2. **Quedarse con lo que tenga el ancho de la cinta.** Se sabe a qué distancia queda cada fila del
   piso, así que se sabe cuántos píxeles debe medir una cinta de 1.9 cm: unos 10 px cerca y unos 3 px
   lejos. Se descartan:
   - la veta de la madera, demasiado delgada;
   - la franja de salida de 18 cm y las sombras, demasiado anchas.
3. **Proyectar al piso.** El centro de cada tramo se proyecta al plano del suelo con la pose de la
   cámara. Resulta una **nube de puntos en metros**, vista desde arriba, sin perspectiva.
4. **Ajustar las rectas y sacar la posición.**
   - RANSAC encuentra las rectas, robusto a puntos sueltos.
   - Se elige el par paralelo separado 72 cm que encierra al robot. Si solo se ve una línea, se usa el
     ancho conocido del carril; con la cámara cerca del piso pasa en ~40 % de las fotos.
   - Salida: `d` (distancia al centro del carril) y `psi` (ángulo respecto a las líneas).
5. **Bonus: la meta.** La franja roja se detecta igual y da su distancia a los pies.

**Salida.** Exactamente las 3 observaciones reservadas del contrato v2 (sección 5.1 del diseño):

| Observación | Unidad | Frecuencia |
|---|---|---|
| `d`: desplazamiento lateral respecto al centro del carril (+ izquierda) | m | 10 Hz, mantenido entre fotos |
| `psi`: ángulo del robot respecto a las líneas (+ izquierda) | rad | 10 Hz, mantenido entre fotos |
| `valido`: 1 si hay medición reciente (< 300 ms) | 0/1 | por ciclo |

**Filtro opcional.** [`lane_filter.py`](../camara/carril/lane_filter.py) combina visión y odometría
con un Kalman de dos estados y rechaza mediciones absurdas. Sirve para el prototipo con la caminata
nativa. Con la política v2 se puede usar el filtro o dejar que la política lo aprenda con el ruido del
paso 71.

---

## 3. Precisión y modelo de error (para el paso 71)

Detalle completo: [`results/camara/modelo_error.md`](../results/camara/modelo_error.md), generado por
[`camara/pruebas/modelo_error.py`](../camara/pruebas/modelo_error.py). Son imágenes sintéticas, cada
fila con 150:
- desplazamiento de ±22 cm y rumbo de ±20°;
- balanceo de la cámara de ±4°;
- madera clara y oscura.

| Condición (error de pose 1.5°) | σ de d | p95 de d | σ de psi | Mediciones malas (> 6 cm o 6°) |
|---|---|---|---|---|
| Base | 1.55 cm | 3.2 cm | 1.18° | 0 % |
| Poca luz | 1.60 cm | 3.3 cm | 1.08° | 0 % |
| Reflejos en la duela | 1.65 cm | 3.1 cm | 1.29° | 0 % |
| Cinta gastada (35 %) | 1.55 cm | 3.0 cm | 1.15° | 0 % |
| Robot vecino tapando una línea | 4.8 cm | 4.0 cm | 4.1° | 2 % |

**El error lo domina la pose de la cámara, no la detección:**

| Error de pose | 0° | 0.5° | 1° | 1.5° | 2° | 3° |
|---|---|---|---|---|---|---|
| σ de d | 0.5 cm | 0.7 cm | 1.1 cm | 1.6 cm | 2.0 cm | 3.0 cm |

Con la pose perfecta, la detección es casi exacta. Las mejoras con más impacto son, por eso:
1. sincronizar la imagen con la pose usando el sello de tiempo de la imagen;
2. corregir el roll y el pitch de la cámara con la IMU.

Intenté una autocorrección de la pose usando el paralelismo de las líneas. **No mejoró**: el roll
desplaza todo el carril de lado por igual y no se detecta con las líneas. Queda desactivada
(`refine=False`).

**Valores iniciales propuestos para simular la cámara en el paso 71**, a recalibrar con la pista real:

| Parámetro | Valor |
|---|---|
| Frecuencia | 10 Hz, valor mantenido entre fotos |
| σ de `d` | 1.6 cm |
| σ de `psi` | 1.2° |
| Retardo | 100–200 ms (coincide con lo previsto en la sección 7 del diseño) |
| Pérdidas | 5–10 % de las fotos (repetir el último valor, `valido = 0`) |
| Mediciones malas | 2–5 % con error uniforme de hasta ±15 cm |

---

## 4. Factibilidad a bordo del NAO

| Requisito (PenaltyStack / NAO) | Cómo se cumple |
|---|---|
| Python 2.7 a bordo, quizá sin numpy | [`lane_estimator_puro.py`](../camara/carril/lane_estimator_puro.py): Python puro, sin dependencias, escrito compatible con 2.7 y 3. Probado en Python 3; **falta correrlo en el Python 2.7 del NAO** (paso 65). Da los mismos resultados que la versión numpy: diferencia de 0.1 cm en [`results/camara/estimador_puro.md`](../results/camara/estimador_puro.md) |
| Tiempo: 10 FPS = 100 ms por foto | Python puro: **13 ms** por imagen en PC. Numpy: **2 ms**. En el Atom E3845 se estiman 3 a 8 veces más: 40–110 ms en puro, 6–16 ms con numpy **(a medir en el paso 65)**. Si no alcanza: procesar 1 de cada 6 filas o bajar a 5 FPS |
| Cámara | La misma suscripción de PenaltyStack: inferior, QVGA, RGB, 10 FPS (`color_order="rgb"`) |
| Pose de la cámara | Cinemática del NAO (`getTransform`) o la de B-Human. No requiere sensores nuevos |
| Sin Wi-Fi, todo a bordo | Todo corre en el NAO. Las imágenes solo se guardan para depurar |
| Arranque y paro | El prototipo usa las teclas de PenaltyStack: táctil frontal 0.25 s y pecho 0.3 s |
| Reglamento | Usar la cámara para ver el carril está permitido explícitamente (sección 3.2.3) |
| Calibración en el evento | Zona de calibraciones (reglamento 2.10): grabar fotos de la duela real y ajustar umbrales con `replay.py` |

---

## 5. Lazo cerrado con la política actual (demo)

[`camara/demo/run_demo.py`](../camara/demo/run_demo.py) hace caminar al NAO V6 en MuJoCo con
`checkpoints/best_model.zip`, sin reentrenarla, sobre la pista de 5 m × 70 cm. La duela y las líneas
tienen las medidas del reglamento.

La cámara inferior simulada alimenta el estimador. Se le agrega 1° de error de pose y 10 % de error en
la odometría.

**Fases de la corrida:**
1. **Medir:** 1.5 s de pie en la salida. La visión mide dónde quedó colocado, con un error de unos
   0.5 cm y 0.7°.
2. **Corregir:** arranca corrigiendo hacia el centro con más ganancia.
3. **Carrera:** sigue con la corrección suave.

Video: [`media/demo_vision_carril.mp4`](../media/demo_vision_carril.mp4).

Demo interactiva: `uv run python camara/demo/run_demo.py --live`. Abre un panel con:
- la posición inicial;
- la visión sí o no;
- los botones Correr y Detener;
- la vista de lo que ve el robot.

**Cómo se corrige el rumbo sin reentrenar, y por qué eso NO es la solución final.** La política actual
no tiene un comando de giro, pero aprendió a anular cualquier giro que perciba. La demo le suma una
señal falsa a la observación del giroscopio, y la política gira hacia el lado contrario. Medido:
- con sesgo de ±0.3, gira unos 3.7°/s sin caerse;
- **con sesgo de 0.5 la respuesta se invierte** y la política gira hacia el lado equivocado.

Funciona como prueba de concepto en un rango pequeño. Pero muestra justamente por qué el camino
correcto es el del plan: **que la política reciba `d` y `psi` como observación (contrato v2, paso 71)**
y aprenda a corregirse con ellas.

---

## 6. Cómo encaja en el plan

- **No toca `src/` ni `configs/`.** No bloquea las fases J a O, como pide la Fase P.
- **Paso 70 (este documento):**
  - Método, salidas, frecuencia y error en simulación: hecho.
  - **Falta la precisión medida en la pista** (criterio de aceptación): `race_nao.py --dry-run` en una
    pista réplica, comparando con cinta métrica, 30 posiciones conocidas.
- **Paso 71:** usar la tabla de la sección 3 para el wrapper de ruido gaussiano de la cámara y agregar
  las 3 observaciones al contrato v2.
- **Paso 72:** integrar `lane_estimator_puro.py` (o la versión numpy si la hay) en el ejecutor de
  PenaltyStack, leyendo la misma suscripción de cámara.
- **Opcional, además:** la cámara también puede **corregir el rumbo objetivo** de la política v1
  (sección 5.3 del diseño: "más adelante la cámara podrá ajustarlo"). Medir `psi` de pie en la salida
  y restarlo del rumbo objetivo elimina el error de colocación, incluso antes de tener la política v2.

---

## 7. Limitaciones y qué falta

- **Todo está medido en simulación.** La duela, la luz y la cinta reales serán distintas. Hay que medir
  en una pista réplica y recalibrar el modelo de error.
- **La precisión depende de la pose de la cámara.** Hay que medir en el robot cuánto error tiene
  `getTransform` mientras camina, y sincronizar la imagen con la pose.
- **El tiempo a bordo es una estimación**, y la compatibilidad con Python 2.7 no se ha probado en un
  intérprete 2.7 real. Las dos cosas se verifican en la sesión 1, junto con la presencia de numpy.
- **Con un robot vecino tapando una línea, el error sube** (σ ≈ 4.8 cm). El filtro y el ancho conocido
  del carril lo amortiguan, pero hay que probarlo.
- **El truco del giroscopio solo sirve para la demo.** La solución es la política v2.

## 8. Cómo reproducir

Desde la raíz del repo; detalle en [`camara/README.md`](../camara/README.md):

```bash
uv run python camara/pruebas/modelo_error.py          # sección 3
uv run python camara/pruebas/comparar_puro.py         # sección 4
uv run python camara/pruebas/evaluar_lazo_cerrado.py  # secciones 1.4 y 5 (~25 min)
uv run python camara/demo/run_demo.py --live          # demo interactiva
uv run python camara/demo/figura_deriva.py            # figura 1.3
uv run python camara/demo/figura_pasos.py             # figura 2
```
